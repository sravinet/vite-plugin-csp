import { Before, After } from '@cucumber/cucumber';

Before(() => {
  // Setup code before each scenario
});

After(() => {
  // Cleanup code after each scenario
});