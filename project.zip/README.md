# Vite Plugin for CSP Headers

This Vite plugin generates Content Security Policy (CSP) headers for Remix projects. It creates an individual JSON file for each route, containing the appropriate CSP headers.

## Installation

To install the plugin, you can add it to your project using npm or yarn:

